--
-- PostgreSQL database cluster dump
--

\restrict xNiHTtLHyMscJc7A4IcuDYvZu3zIEXqUAwd4TDFpWUaNqQHcGWlLjecNcUqJxak

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:SoV9Sd60VtzZu+Ag6jRpfg==$kEz2ANAJwizkNMoHm+4PDcLkp1M8HNGeXazrBpDrS6Y=:w7xfWdBvhVybZMhkqwcB/Z9goUv7FXoPTjMeo54lZ3I=';

--
-- User Configurations
--








\unrestrict xNiHTtLHyMscJc7A4IcuDYvZu3zIEXqUAwd4TDFpWUaNqQHcGWlLjecNcUqJxak

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict 24VfifouSTLU8fbQU5xtitQJSPtekbnsP7c9oOHm2aUNaKfXsDloLH96hPP4gBx

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg12+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 24VfifouSTLU8fbQU5xtitQJSPtekbnsP7c9oOHm2aUNaKfXsDloLH96hPP4gBx

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict gIBnoXxRqCNOSv5SdVIg5muhh0nnLavamdlrqKDaGVJGg3D1XuUKW2lXzm0G8A6

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg12+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: campaign_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.campaign_state AS ENUM (
    'created',
    'syncing',
    'running',
    'paused',
    'completed',
    'failed'
);


ALTER TYPE public.campaign_state OWNER TO postgres;

--
-- Name: document_processing_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.document_processing_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed'
);


ALTER TYPE public.document_processing_status OWNER TO postgres;

--
-- Name: queued_run_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.queued_run_state AS ENUM (
    'queued',
    'processed',
    'processing',
    'failed'
);


ALTER TYPE public.queued_run_state OWNER TO postgres;

--
-- Name: quota_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quota_type AS ENUM (
    'monthly',
    'annual'
);


ALTER TYPE public.quota_type OWNER TO postgres;

--
-- Name: storage_backend; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.storage_backend AS ENUM (
    's3',
    'minio'
);


ALTER TYPE public.storage_backend OWNER TO postgres;

--
-- Name: test_session_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.test_session_status AS ENUM (
    'pending',
    'running',
    'completed',
    'failed'
);


ALTER TYPE public.test_session_status OWNER TO postgres;

--
-- Name: tool_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tool_category AS ENUM (
    'http_api',
    'end_call',
    'transfer_call',
    'native',
    'integration'
);


ALTER TYPE public.tool_category OWNER TO postgres;

--
-- Name: tool_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tool_status AS ENUM (
    'active',
    'archived',
    'draft'
);


ALTER TYPE public.tool_status OWNER TO postgres;

--
-- Name: trigger_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.trigger_state AS ENUM (
    'active',
    'archived'
);


ALTER TYPE public.trigger_state OWNER TO postgres;

--
-- Name: webhook_credential_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.webhook_credential_type AS ENUM (
    'none',
    'api_key',
    'bearer_token',
    'basic_auth',
    'custom_header'
);


ALTER TYPE public.webhook_credential_type OWNER TO postgres;

--
-- Name: workflow_call_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.workflow_call_type AS ENUM (
    'inbound',
    'outbound'
);


ALTER TYPE public.workflow_call_type OWNER TO postgres;

--
-- Name: workflow_run_mode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.workflow_run_mode AS ENUM (
    'ari',
    'twilio',
    'vonage',
    'vobiz',
    'cloudonix',
    'webrtc',
    'smallwebrtc',
    'stasis',
    'VOICE',
    'CHAT'
);


ALTER TYPE public.workflow_run_mode OWNER TO postgres;

--
-- Name: workflow_run_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.workflow_run_state AS ENUM (
    'initialized',
    'running',
    'completed'
);


ALTER TYPE public.workflow_run_state OWNER TO postgres;

--
-- Name: workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.workflow_status AS ENUM (
    'active',
    'archived'
);


ALTER TYPE public.workflow_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_triggers (
    id integer NOT NULL,
    trigger_path character varying(36) NOT NULL,
    workflow_id integer NOT NULL,
    organization_id integer NOT NULL,
    state public.trigger_state DEFAULT 'active'::public.trigger_state NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.agent_triggers OWNER TO postgres;

--
-- Name: agent_triggers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agent_triggers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_triggers_id_seq OWNER TO postgres;

--
-- Name: agent_triggers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agent_triggers_id_seq OWNED BY public.agent_triggers.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    organization_id integer NOT NULL,
    name character varying NOT NULL,
    key_hash character varying NOT NULL,
    key_prefix character varying NOT NULL,
    is_active boolean NOT NULL,
    created_by integer,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone,
    archived_at timestamp with time zone
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO postgres;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: apscheduler_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.apscheduler_jobs (
    id character varying(191) NOT NULL,
    next_run_time double precision,
    job_state bytea NOT NULL
);


ALTER TABLE public.apscheduler_jobs OWNER TO postgres;

--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campaigns (
    id integer NOT NULL,
    name character varying NOT NULL,
    organization_id integer NOT NULL,
    workflow_id integer NOT NULL,
    created_by integer NOT NULL,
    source_type character varying NOT NULL,
    source_id character varying NOT NULL,
    state public.campaign_state NOT NULL,
    total_rows integer,
    processed_rows integer NOT NULL,
    failed_rows integer NOT NULL,
    created_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone,
    rate_limit_per_second integer NOT NULL,
    max_retries integer NOT NULL,
    source_sync_status character varying NOT NULL,
    source_last_synced_at timestamp with time zone,
    source_sync_error character varying,
    retry_config json DEFAULT '{"enabled": true, "max_retries": 2, "retry_on_busy": true, "retry_on_no_answer": true, "retry_on_voicemail": true, "retry_delay_seconds": 120}'::jsonb NOT NULL,
    last_batch_scheduled_at timestamp with time zone,
    last_activity_at timestamp with time zone,
    orchestrator_metadata json DEFAULT '{}'::json NOT NULL
);


ALTER TABLE public.campaigns OWNER TO postgres;

--
-- Name: campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.campaigns_id_seq OWNER TO postgres;

--
-- Name: campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaigns_id_seq OWNED BY public.campaigns.id;


--
-- Name: embed_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.embed_sessions (
    id integer NOT NULL,
    session_token character varying(255) NOT NULL,
    embed_token_id integer NOT NULL,
    workflow_run_id integer,
    client_ip character varying(45),
    user_agent character varying(500),
    origin character varying(255),
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.embed_sessions OWNER TO postgres;

--
-- Name: embed_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.embed_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.embed_sessions_id_seq OWNER TO postgres;

--
-- Name: embed_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.embed_sessions_id_seq OWNED BY public.embed_sessions.id;


--
-- Name: embed_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.embed_tokens (
    id integer NOT NULL,
    token character varying(255) NOT NULL,
    workflow_id integer NOT NULL,
    organization_id integer NOT NULL,
    allowed_domains json,
    settings json,
    is_active boolean NOT NULL,
    usage_limit integer,
    usage_count integer NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone,
    created_by integer NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.embed_tokens OWNER TO postgres;

--
-- Name: embed_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.embed_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.embed_tokens_id_seq OWNER TO postgres;

--
-- Name: embed_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.embed_tokens_id_seq OWNED BY public.embed_tokens.id;


--
-- Name: external_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.external_credentials (
    id integer NOT NULL,
    credential_uuid character varying(36) NOT NULL,
    organization_id integer NOT NULL,
    name character varying NOT NULL,
    description character varying,
    credential_type public.webhook_credential_type NOT NULL,
    credential_data json NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_active boolean NOT NULL
);


ALTER TABLE public.external_credentials OWNER TO postgres;

--
-- Name: external_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.external_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.external_credentials_id_seq OWNER TO postgres;

--
-- Name: external_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.external_credentials_id_seq OWNED BY public.external_credentials.id;


--
-- Name: fazle_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fazle_tasks (
    id character varying(36) NOT NULL,
    title character varying(500) NOT NULL,
    description text DEFAULT ''::text,
    task_type character varying(50) DEFAULT 'reminder'::character varying NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    scheduled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.fazle_tasks OWNER TO postgres;

--
-- Name: integrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrations (
    id integer NOT NULL,
    integration_id character varying NOT NULL,
    organisation_id integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone,
    created_by integer,
    provider character varying NOT NULL,
    connection_details json NOT NULL,
    action character varying NOT NULL
);


ALTER TABLE public.integrations OWNER TO postgres;

--
-- Name: integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.integrations_id_seq OWNER TO postgres;

--
-- Name: integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.integrations_id_seq OWNED BY public.integrations.id;


--
-- Name: knowledge_base_chunks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knowledge_base_chunks (
    id integer NOT NULL,
    document_id integer NOT NULL,
    organization_id integer NOT NULL,
    chunk_text text NOT NULL,
    contextualized_text text,
    chunk_index integer NOT NULL,
    chunk_metadata json NOT NULL,
    embedding_model character varying(200) NOT NULL,
    embedding_dimension integer NOT NULL,
    embedding public.vector(1536),
    token_count integer,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.knowledge_base_chunks OWNER TO postgres;

--
-- Name: knowledge_base_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knowledge_base_chunks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_base_chunks_id_seq OWNER TO postgres;

--
-- Name: knowledge_base_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knowledge_base_chunks_id_seq OWNED BY public.knowledge_base_chunks.id;


--
-- Name: knowledge_base_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knowledge_base_documents (
    id integer NOT NULL,
    document_uuid character varying(36) NOT NULL,
    organization_id integer NOT NULL,
    filename character varying(500) NOT NULL,
    file_size_bytes integer,
    file_hash character varying(64),
    mime_type character varying(100),
    source_url character varying,
    total_chunks integer NOT NULL,
    processing_status public.document_processing_status DEFAULT 'pending'::public.document_processing_status NOT NULL,
    processing_error text,
    docling_metadata json NOT NULL,
    custom_metadata json NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_active boolean NOT NULL,
    archived_at timestamp with time zone
);


ALTER TABLE public.knowledge_base_documents OWNER TO postgres;

--
-- Name: knowledge_base_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knowledge_base_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_base_documents_id_seq OWNER TO postgres;

--
-- Name: knowledge_base_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knowledge_base_documents_id_seq OWNED BY public.knowledge_base_documents.id;


--
-- Name: looptalk_conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.looptalk_conversations (
    id integer NOT NULL,
    test_session_id integer NOT NULL,
    duration_seconds integer,
    actor_recording_url character varying,
    adversary_recording_url character varying,
    combined_recording_url character varying,
    transcript json NOT NULL,
    metrics json NOT NULL,
    created_at timestamp with time zone,
    ended_at timestamp with time zone
);


ALTER TABLE public.looptalk_conversations OWNER TO postgres;

--
-- Name: looptalk_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.looptalk_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.looptalk_conversations_id_seq OWNER TO postgres;

--
-- Name: looptalk_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.looptalk_conversations_id_seq OWNED BY public.looptalk_conversations.id;


--
-- Name: looptalk_test_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.looptalk_test_sessions (
    id integer NOT NULL,
    organization_id integer NOT NULL,
    name character varying NOT NULL,
    status public.test_session_status NOT NULL,
    actor_workflow_id integer NOT NULL,
    adversary_workflow_id integer NOT NULL,
    load_test_group_id character varying,
    test_index integer,
    config json NOT NULL,
    results json NOT NULL,
    error character varying,
    created_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.looptalk_test_sessions OWNER TO postgres;

--
-- Name: looptalk_test_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.looptalk_test_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.looptalk_test_sessions_id_seq OWNER TO postgres;

--
-- Name: looptalk_test_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.looptalk_test_sessions_id_seq OWNED BY public.looptalk_test_sessions.id;


--
-- Name: organization_configurations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_configurations (
    id integer NOT NULL,
    organization_id integer NOT NULL,
    key character varying NOT NULL,
    value json NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.organization_configurations OWNER TO postgres;

--
-- Name: organization_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organization_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organization_configurations_id_seq OWNER TO postgres;

--
-- Name: organization_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organization_configurations_id_seq OWNED BY public.organization_configurations.id;


--
-- Name: organization_usage_cycles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_usage_cycles (
    id integer NOT NULL,
    organization_id integer NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    quota_dograh_tokens integer NOT NULL,
    used_dograh_tokens double precision NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    total_duration_seconds integer DEFAULT 0 NOT NULL,
    used_amount_usd double precision,
    quota_amount_usd double precision
);


ALTER TABLE public.organization_usage_cycles OWNER TO postgres;

--
-- Name: organization_usage_cycles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organization_usage_cycles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organization_usage_cycles_id_seq OWNER TO postgres;

--
-- Name: organization_usage_cycles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organization_usage_cycles_id_seq OWNED BY public.organization_usage_cycles.id;


--
-- Name: organization_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_users (
    user_id integer NOT NULL,
    organization_id integer NOT NULL
);


ALTER TABLE public.organization_users OWNER TO postgres;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    provider_id character varying NOT NULL,
    created_at timestamp with time zone,
    quota_type public.quota_type DEFAULT 'monthly'::public.quota_type NOT NULL,
    quota_dograh_tokens integer DEFAULT 0 NOT NULL,
    quota_reset_day integer DEFAULT 1 NOT NULL,
    quota_start_date timestamp with time zone,
    quota_enabled boolean DEFAULT false NOT NULL,
    price_per_second_usd double precision
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizations_id_seq OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: queued_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.queued_runs (
    id integer NOT NULL,
    campaign_id integer NOT NULL,
    source_uuid character varying NOT NULL,
    context_variables json NOT NULL,
    state public.queued_run_state NOT NULL,
    created_at timestamp with time zone,
    processed_at timestamp with time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    parent_queued_run_id integer,
    scheduled_for timestamp with time zone,
    retry_reason character varying
);


ALTER TABLE public.queued_runs OWNER TO postgres;

--
-- Name: queued_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.queued_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.queued_runs_id_seq OWNER TO postgres;

--
-- Name: queued_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.queued_runs_id_seq OWNED BY public.queued_runs.id;


--
-- Name: tools; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tools (
    id integer NOT NULL,
    tool_uuid character varying(36) NOT NULL,
    organization_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying,
    category public.tool_category NOT NULL,
    icon character varying(50),
    icon_color character varying(7),
    status public.tool_status DEFAULT 'active'::public.tool_status NOT NULL,
    definition json NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tools OWNER TO postgres;

--
-- Name: tools_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tools_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tools_id_seq OWNER TO postgres;

--
-- Name: tools_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tools_id_seq OWNED BY public.tools.id;


--
-- Name: user_configurations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_configurations (
    id integer NOT NULL,
    user_id integer,
    configuration json NOT NULL,
    last_validated_at timestamp with time zone
);


ALTER TABLE public.user_configurations OWNER TO postgres;

--
-- Name: user_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_configurations_id_seq OWNER TO postgres;

--
-- Name: user_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_configurations_id_seq OWNED BY public.user_configurations.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    provider_id character varying NOT NULL,
    created_at timestamp with time zone,
    is_superuser boolean,
    selected_organization_id integer,
    email character varying,
    password_hash character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workflow_definitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_definitions (
    id integer NOT NULL,
    workflow_hash character varying NOT NULL,
    workflow_json json NOT NULL,
    created_at timestamp with time zone,
    workflow_id integer,
    is_current boolean DEFAULT false NOT NULL
);


ALTER TABLE public.workflow_definitions OWNER TO postgres;

--
-- Name: workflow_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workflow_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_definitions_id_seq OWNER TO postgres;

--
-- Name: workflow_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workflow_definitions_id_seq OWNED BY public.workflow_definitions.id;


--
-- Name: workflow_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_runs (
    id integer NOT NULL,
    name character varying NOT NULL,
    workflow_id integer NOT NULL,
    mode public.workflow_run_mode NOT NULL,
    created_at timestamp with time zone,
    is_completed boolean,
    recording_url character varying,
    transcript_url character varying,
    usage_info json NOT NULL,
    cost_info json NOT NULL,
    initial_context json NOT NULL,
    gathered_context json NOT NULL,
    definition_id integer,
    annotations json NOT NULL,
    campaign_id integer,
    logs json DEFAULT '{}'::json NOT NULL,
    queued_run_id integer,
    storage_backend public.storage_backend DEFAULT 's3'::public.storage_backend NOT NULL,
    state public.workflow_run_state DEFAULT 'initialized'::public.workflow_run_state NOT NULL,
    call_type public.workflow_call_type DEFAULT 'outbound'::public.workflow_call_type NOT NULL,
    public_access_token character varying(36)
);


ALTER TABLE public.workflow_runs OWNER TO postgres;

--
-- Name: workflow_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workflow_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_runs_id_seq OWNER TO postgres;

--
-- Name: workflow_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workflow_runs_id_seq OWNED BY public.workflow_runs.id;


--
-- Name: workflow_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_templates (
    id integer NOT NULL,
    template_name character varying NOT NULL,
    template_json json NOT NULL,
    created_at timestamp with time zone,
    template_description character varying NOT NULL
);


ALTER TABLE public.workflow_templates OWNER TO postgres;

--
-- Name: workflow_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workflow_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_templates_id_seq OWNER TO postgres;

--
-- Name: workflow_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workflow_templates_id_seq OWNED BY public.workflow_templates.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    name character varying NOT NULL,
    workflow_definition json NOT NULL,
    created_at timestamp with time zone,
    user_id integer,
    template_context_variables json NOT NULL,
    call_disposition_codes json NOT NULL,
    organization_id integer,
    status public.workflow_status DEFAULT 'active'::public.workflow_status NOT NULL,
    workflow_configurations json DEFAULT '{}'::json NOT NULL
);


ALTER TABLE public.workflows OWNER TO postgres;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO postgres;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: agent_triggers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_triggers ALTER COLUMN id SET DEFAULT nextval('public.agent_triggers_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: campaigns id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns ALTER COLUMN id SET DEFAULT nextval('public.campaigns_id_seq'::regclass);


--
-- Name: embed_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_sessions ALTER COLUMN id SET DEFAULT nextval('public.embed_sessions_id_seq'::regclass);


--
-- Name: embed_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_tokens ALTER COLUMN id SET DEFAULT nextval('public.embed_tokens_id_seq'::regclass);


--
-- Name: external_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_credentials ALTER COLUMN id SET DEFAULT nextval('public.external_credentials_id_seq'::regclass);


--
-- Name: integrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations ALTER COLUMN id SET DEFAULT nextval('public.integrations_id_seq'::regclass);


--
-- Name: knowledge_base_chunks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base_chunks ALTER COLUMN id SET DEFAULT nextval('public.knowledge_base_chunks_id_seq'::regclass);


--
-- Name: knowledge_base_documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base_documents ALTER COLUMN id SET DEFAULT nextval('public.knowledge_base_documents_id_seq'::regclass);


--
-- Name: looptalk_conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.looptalk_conversations ALTER COLUMN id SET DEFAULT nextval('public.looptalk_conversations_id_seq'::regclass);


--
-- Name: looptalk_test_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.looptalk_test_sessions ALTER COLUMN id SET DEFAULT nextval('public.looptalk_test_sessions_id_seq'::regclass);


--
-- Name: organization_configurations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_configurations ALTER COLUMN id SET DEFAULT nextval('public.organization_configurations_id_seq'::regclass);


--
-- Name: organization_usage_cycles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_usage_cycles ALTER COLUMN id SET DEFAULT nextval('public.organization_usage_cycles_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: queued_runs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queued_runs ALTER COLUMN id SET DEFAULT nextval('public.queued_runs_id_seq'::regclass);


--
-- Name: tools id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools ALTER COLUMN id SET DEFAULT nextval('public.tools_id_seq'::regclass);


--
-- Name: user_configurations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_configurations ALTER COLUMN id SET DEFAULT nextval('public.user_configurations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: workflow_definitions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_definitions ALTER COLUMN id SET DEFAULT nextval('public.workflow_definitions_id_seq'::regclass);


--
-- Name: workflow_runs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_runs ALTER COLUMN id SET DEFAULT nextval('public.workflow_runs_id_seq'::regclass);


--
-- Name: workflow_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_templates ALTER COLUMN id SET DEFAULT nextval('public.workflow_templates_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: agent_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_triggers (id, trigger_path, workflow_id, organization_id, state, created_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
6fd8fac02883
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, organization_id, name, key_hash, key_prefix, is_active, created_by, last_used_at, created_at, archived_at) FROM stdin;
1	1	Default API Key	0f34a36b78ed5b3307077b7e38733b18e6c07a3a1eafbeab07f29efb84a964dd	dgr_7pRN	t	1	\N	2026-03-07 01:52:29.507163+00	\N
2	2	Default API Key	0c5afe9280e3846b197864cacc5046fe2e6c21a740185ef4fcf0b733d9697314	dgr_6Ikw	t	2	\N	2026-03-07 03:22:04.307334+00	\N
\.


--
-- Data for Name: apscheduler_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.apscheduler_jobs (id, next_run_time, job_state) FROM stdin;
\.


--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.campaigns (id, name, organization_id, workflow_id, created_by, source_type, source_id, state, total_rows, processed_rows, failed_rows, created_at, started_at, completed_at, updated_at, rate_limit_per_second, max_retries, source_sync_status, source_last_synced_at, source_sync_error, retry_config, last_batch_scheduled_at, last_activity_at, orchestrator_metadata) FROM stdin;
\.


--
-- Data for Name: embed_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.embed_sessions (id, session_token, embed_token_id, workflow_run_id, client_ip, user_agent, origin, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: embed_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.embed_tokens (id, token, workflow_id, organization_id, allowed_domains, settings, is_active, usage_limit, usage_count, expires_at, created_at, created_by, updated_at) FROM stdin;
\.


--
-- Data for Name: external_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.external_credentials (id, credential_uuid, organization_id, name, description, credential_type, credential_data, created_by, created_at, updated_at, is_active) FROM stdin;
\.


--
-- Data for Name: fazle_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fazle_tasks (id, title, description, task_type, status, scheduled_at, created_at, payload) FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integrations (id, integration_id, organisation_id, is_active, created_at, created_by, provider, connection_details, action) FROM stdin;
\.


--
-- Data for Name: knowledge_base_chunks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.knowledge_base_chunks (id, document_id, organization_id, chunk_text, contextualized_text, chunk_index, chunk_metadata, embedding_model, embedding_dimension, embedding, token_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_base_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.knowledge_base_documents (id, document_uuid, organization_id, filename, file_size_bytes, file_hash, mime_type, source_url, total_chunks, processing_status, processing_error, docling_metadata, custom_metadata, created_by, created_at, updated_at, is_active, archived_at) FROM stdin;
\.


--
-- Data for Name: looptalk_conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.looptalk_conversations (id, test_session_id, duration_seconds, actor_recording_url, adversary_recording_url, combined_recording_url, transcript, metrics, created_at, ended_at) FROM stdin;
\.


--
-- Data for Name: looptalk_test_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.looptalk_test_sessions (id, organization_id, name, status, actor_workflow_id, adversary_workflow_id, load_test_group_id, test_index, config, results, error, created_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: organization_configurations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_configurations (id, organization_id, key, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_usage_cycles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_usage_cycles (id, organization_id, period_start, period_end, quota_dograh_tokens, used_dograh_tokens, created_at, updated_at, total_duration_seconds, used_amount_usd, quota_amount_usd) FROM stdin;
\.


--
-- Data for Name: organization_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_users (user_id, organization_id) FROM stdin;
1	1
2	2
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (id, provider_id, created_at, quota_type, quota_dograh_tokens, quota_reset_day, quota_start_date, quota_enabled, price_per_second_usd) FROM stdin;
1	org_oss_1772848349_8dc62835-3e5e-4e54-b724-8c8aebe166b8	2026-03-07 01:52:29.496346+00	monthly	0	1	\N	f	\N
2	org_oss_1772853724_7982a4d2-1c29-4e84-81fc-d4b8ab089466	2026-03-07 03:22:04.293937+00	monthly	0	1	\N	f	\N
\.


--
-- Data for Name: queued_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.queued_runs (id, campaign_id, source_uuid, context_variables, state, created_at, processed_at, retry_count, parent_queued_run_id, scheduled_for, retry_reason) FROM stdin;
\.


--
-- Data for Name: tools; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tools (id, tool_uuid, organization_id, name, description, category, icon, icon_color, status, definition, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_configurations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_configurations (id, user_id, configuration, last_validated_at) FROM stdin;
1	1	{"llm": {"provider": "dograh", "api_key": "oss_sk_hk5aZG1Na2uqNJKkEEizchWTLuoYGQFK", "model": "default"}, "stt": {"provider": "dograh", "api_key": "oss_sk_hk5aZG1Na2uqNJKkEEizchWTLuoYGQFK", "model": "default", "language": "multi"}, "tts": {"provider": "dograh", "api_key": "oss_sk_hk5aZG1Na2uqNJKkEEizchWTLuoYGQFK", "model": "default", "voice": "default", "speed": 1.0}, "embeddings": null, "test_phone_number": null, "timezone": null, "last_validated_at": null}	\N
2	2	{"llm": {"provider": "dograh", "api_key": "oss_sk_ffF02wHOVtwNthOo5LCnGgNshlAD0fpB", "model": "default"}, "stt": {"provider": "dograh", "api_key": "oss_sk_ffF02wHOVtwNthOo5LCnGgNshlAD0fpB", "model": "default", "language": "multi"}, "tts": {"provider": "dograh", "api_key": "oss_sk_ffF02wHOVtwNthOo5LCnGgNshlAD0fpB", "model": "default", "voice": "default", "speed": 1.0}, "embeddings": null, "test_phone_number": null, "timezone": null, "last_validated_at": null}	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, provider_id, created_at, is_superuser, selected_organization_id, email, password_hash) FROM stdin;
1	oss_1772848349_8dc62835-3e5e-4e54-b724-8c8aebe166b8	2026-03-07 01:52:29.460821+00	f	1	admin@iamazim.com	$2b$12$N2S1Cf0ri0p4XWwIFaAWTelkSuBR9.8k.OZ1G8Gof.d1r6ZkTc50S
2	oss_1772853724_7982a4d2-1c29-4e84-81fc-d4b8ab089466	2026-03-07 03:22:04.274074+00	f	2	test3@iamazim.com	$2b$12$NUqwPkCln42H9c9ReNGetOS4ysu1sf6ZXoWBNcFGC6iV2k6wR45pu
\.


--
-- Data for Name: workflow_definitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_definitions (id, workflow_hash, workflow_json, created_at, workflow_id, is_current) FROM stdin;
\.


--
-- Data for Name: workflow_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_runs (id, name, workflow_id, mode, created_at, is_completed, recording_url, transcript_url, usage_info, cost_info, initial_context, gathered_context, definition_id, annotations, campaign_id, logs, queued_run_id, storage_backend, state, call_type, public_access_token) FROM stdin;
\.


--
-- Data for Name: workflow_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_templates (id, template_name, template_json, created_at, template_description) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflows (id, name, workflow_definition, created_at, user_id, template_context_variables, call_disposition_codes, organization_id, status, workflow_configurations) FROM stdin;
\.


--
-- Name: agent_triggers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agent_triggers_id_seq', 1, false);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 2, true);


--
-- Name: campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaigns_id_seq', 1, false);


--
-- Name: embed_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.embed_sessions_id_seq', 1, false);


--
-- Name: embed_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.embed_tokens_id_seq', 1, false);


--
-- Name: external_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.external_credentials_id_seq', 1, false);


--
-- Name: integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.integrations_id_seq', 1, false);


--
-- Name: knowledge_base_chunks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knowledge_base_chunks_id_seq', 1, false);


--
-- Name: knowledge_base_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knowledge_base_documents_id_seq', 1, false);


--
-- Name: looptalk_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.looptalk_conversations_id_seq', 1, false);


--
-- Name: looptalk_test_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.looptalk_test_sessions_id_seq', 1, false);


--
-- Name: organization_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organization_configurations_id_seq', 1, false);


--
-- Name: organization_usage_cycles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organization_usage_cycles_id_seq', 1, false);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_id_seq', 2, true);


--
-- Name: queued_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.queued_runs_id_seq', 1, false);


--
-- Name: tools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tools_id_seq', 1, false);


--
-- Name: user_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_configurations_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: workflow_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workflow_definitions_id_seq', 1, false);


--
-- Name: workflow_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workflow_runs_id_seq', 1, false);


--
-- Name: workflow_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workflow_templates_id_seq', 1, false);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1, false);


--
-- Name: organization_configurations _organization_key_uc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_configurations
    ADD CONSTRAINT _organization_key_uc UNIQUE (organization_id, key);


--
-- Name: agent_triggers agent_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: apscheduler_jobs apscheduler_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apscheduler_jobs
    ADD CONSTRAINT apscheduler_jobs_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: embed_sessions embed_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_sessions
    ADD CONSTRAINT embed_sessions_pkey PRIMARY KEY (id);


--
-- Name: embed_tokens embed_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_tokens
    ADD CONSTRAINT embed_tokens_pkey PRIMARY KEY (id);


--
-- Name: external_credentials external_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_credentials
    ADD CONSTRAINT external_credentials_pkey PRIMARY KEY (id);


--
-- Name: fazle_tasks fazle_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fazle_tasks
    ADD CONSTRAINT fazle_tasks_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: knowledge_base_chunks knowledge_base_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base_chunks
    ADD CONSTRAINT knowledge_base_chunks_pkey PRIMARY KEY (id);


--
-- Name: knowledge_base_documents knowledge_base_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base_documents
    ADD CONSTRAINT knowledge_base_documents_pkey PRIMARY KEY (id);


--
-- Name: looptalk_conversations looptalk_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.looptalk_conversations
    ADD CONSTRAINT looptalk_conversations_pkey PRIMARY KEY (id);


--
-- Name: looptalk_test_sessions looptalk_test_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.looptalk_test_sessions
    ADD CONSTRAINT looptalk_test_sessions_pkey PRIMARY KEY (id);


--
-- Name: organization_configurations organization_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_configurations
    ADD CONSTRAINT organization_configurations_pkey PRIMARY KEY (id);


--
-- Name: organization_usage_cycles organization_usage_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_usage_cycles
    ADD CONSTRAINT organization_usage_cycles_pkey PRIMARY KEY (id);


--
-- Name: organization_users organization_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_pkey PRIMARY KEY (user_id, organization_id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: queued_runs queued_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queued_runs
    ADD CONSTRAINT queued_runs_pkey PRIMARY KEY (id);


--
-- Name: tools tools_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_pkey PRIMARY KEY (id);


--
-- Name: queued_runs unique_campaign_source_retry; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queued_runs
    ADD CONSTRAINT unique_campaign_source_retry UNIQUE (campaign_id, source_uuid, retry_count);


--
-- Name: external_credentials unique_org_credential_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_credentials
    ADD CONSTRAINT unique_org_credential_name UNIQUE (organization_id, name);


--
-- Name: organization_usage_cycles unique_org_period; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_usage_cycles
    ADD CONSTRAINT unique_org_period UNIQUE (organization_id, period_start, period_end);


--
-- Name: workflow_definitions uq_workflow_hash_workflow_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT uq_workflow_hash_workflow_id UNIQUE (workflow_hash, workflow_id);


--
-- Name: user_configurations user_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_configurations
    ADD CONSTRAINT user_configurations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workflow_definitions workflow_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT workflow_definitions_pkey PRIMARY KEY (id);


--
-- Name: workflow_runs workflow_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_pkey PRIMARY KEY (id);


--
-- Name: workflow_templates workflow_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_templates
    ADD CONSTRAINT workflow_templates_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_campaigns_active_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_campaigns_active_status ON public.campaigns USING btree (state) WHERE (state = ANY (ARRAY['syncing'::public.campaign_state, 'running'::public.campaign_state, 'paused'::public.campaign_state]));


--
-- Name: idx_fazle_tasks_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fazle_tasks_created ON public.fazle_tasks USING btree (created_at DESC);


--
-- Name: idx_fazle_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fazle_tasks_status ON public.fazle_tasks USING btree (status);


--
-- Name: idx_fazle_tasks_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fazle_tasks_type ON public.fazle_tasks USING btree (task_type);


--
-- Name: idx_queued_runs_campaign_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queued_runs_campaign_state ON public.queued_runs USING btree (campaign_id, state);


--
-- Name: idx_queued_runs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queued_runs_created ON public.queued_runs USING btree (created_at);


--
-- Name: idx_queued_runs_scheduled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queued_runs_scheduled ON public.queued_runs USING btree (scheduled_for);


--
-- Name: idx_queued_runs_scheduled_optimized; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queued_runs_scheduled_optimized ON public.queued_runs USING btree (campaign_id, scheduled_for) WHERE (scheduled_for IS NOT NULL);


--
-- Name: idx_queued_runs_source_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queued_runs_source_uuid ON public.queued_runs USING btree (source_uuid);


--
-- Name: idx_usage_cycles_org_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_usage_cycles_org_period ON public.organization_usage_cycles USING btree (organization_id, period_end);


--
-- Name: idx_workflow_runs_call_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_runs_call_id ON public.workflow_runs USING btree (((gathered_context ->> 'call_id'::text))) WHERE ((gathered_context ->> 'call_id'::text) IS NOT NULL);


--
-- Name: idx_workflow_runs_campaign_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_runs_campaign_id ON public.workflow_runs USING btree (campaign_id);


--
-- Name: idx_workflow_runs_public_access_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_workflow_runs_public_access_token ON public.workflow_runs USING btree (public_access_token) WHERE (public_access_token IS NOT NULL);


--
-- Name: idx_workflow_runs_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_runs_workflow_id ON public.workflow_runs USING btree (workflow_id);


--
-- Name: ix_agent_triggers_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_agent_triggers_state ON public.agent_triggers USING btree (state);


--
-- Name: ix_agent_triggers_trigger_path; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_agent_triggers_trigger_path ON public.agent_triggers USING btree (trigger_path);


--
-- Name: ix_agent_triggers_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_agent_triggers_workflow_id ON public.agent_triggers USING btree (workflow_id);


--
-- Name: ix_api_keys_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_api_keys_active ON public.api_keys USING btree (is_active);


--
-- Name: ix_api_keys_key_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_api_keys_key_hash ON public.api_keys USING btree (key_hash);


--
-- Name: ix_api_keys_organization_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_api_keys_organization_id ON public.api_keys USING btree (organization_id);


--
-- Name: ix_apscheduler_jobs_next_run_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_apscheduler_jobs_next_run_time ON public.apscheduler_jobs USING btree (next_run_time);


--
-- Name: ix_campaigns_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_campaigns_name ON public.campaigns USING btree (name);


--
-- Name: ix_campaigns_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_campaigns_org_id ON public.campaigns USING btree (organization_id);


--
-- Name: ix_campaigns_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_campaigns_state ON public.campaigns USING btree (state);


--
-- Name: ix_campaigns_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_campaigns_workflow_id ON public.campaigns USING btree (workflow_id);


--
-- Name: ix_embed_sessions_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_embed_sessions_expires_at ON public.embed_sessions USING btree (expires_at);


--
-- Name: ix_embed_sessions_session_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_embed_sessions_session_token ON public.embed_sessions USING btree (session_token);


--
-- Name: ix_embed_tokens_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_embed_tokens_is_active ON public.embed_tokens USING btree (is_active);


--
-- Name: ix_embed_tokens_organization_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_embed_tokens_organization_id ON public.embed_tokens USING btree (organization_id);


--
-- Name: ix_embed_tokens_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_embed_tokens_token ON public.embed_tokens USING btree (token);


--
-- Name: ix_embed_tokens_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_embed_tokens_workflow_id ON public.embed_tokens USING btree (workflow_id);


--
-- Name: ix_external_credentials_credential_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_external_credentials_credential_uuid ON public.external_credentials USING btree (credential_uuid);


--
-- Name: ix_integrations_integration_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_integrations_integration_id ON public.integrations USING btree (integration_id);


--
-- Name: ix_kb_chunks_chunk_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_chunks_chunk_index ON public.knowledge_base_chunks USING btree (chunk_index);


--
-- Name: ix_kb_chunks_document_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_chunks_document_id ON public.knowledge_base_chunks USING btree (document_id);


--
-- Name: ix_kb_chunks_embedding_ivfflat; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_chunks_embedding_ivfflat ON public.knowledge_base_chunks USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: ix_kb_chunks_embedding_model; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_chunks_embedding_model ON public.knowledge_base_chunks USING btree (embedding_model);


--
-- Name: ix_kb_chunks_organization_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_chunks_organization_id ON public.knowledge_base_chunks USING btree (organization_id);


--
-- Name: ix_kb_documents_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_documents_created_at ON public.knowledge_base_documents USING btree (created_at);


--
-- Name: ix_kb_documents_organization_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_documents_organization_id ON public.knowledge_base_documents USING btree (organization_id);


--
-- Name: ix_kb_documents_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_documents_status ON public.knowledge_base_documents USING btree (processing_status);


--
-- Name: ix_kb_documents_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_kb_documents_uuid ON public.knowledge_base_documents USING btree (document_uuid);


--
-- Name: ix_knowledge_base_documents_document_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_knowledge_base_documents_document_uuid ON public.knowledge_base_documents USING btree (document_uuid);


--
-- Name: ix_looptalk_conversations_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_looptalk_conversations_id ON public.looptalk_conversations USING btree (id);


--
-- Name: ix_looptalk_conversations_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_looptalk_conversations_session_id ON public.looptalk_conversations USING btree (test_session_id);


--
-- Name: ix_looptalk_test_sessions_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_looptalk_test_sessions_group_id ON public.looptalk_test_sessions USING btree (load_test_group_id);


--
-- Name: ix_looptalk_test_sessions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_looptalk_test_sessions_id ON public.looptalk_test_sessions USING btree (id);


--
-- Name: ix_looptalk_test_sessions_load_test_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_looptalk_test_sessions_load_test_group_id ON public.looptalk_test_sessions USING btree (load_test_group_id);


--
-- Name: ix_looptalk_test_sessions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_looptalk_test_sessions_org_id ON public.looptalk_test_sessions USING btree (organization_id);


--
-- Name: ix_looptalk_test_sessions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_looptalk_test_sessions_status ON public.looptalk_test_sessions USING btree (status);


--
-- Name: ix_organization_configurations_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_organization_configurations_id ON public.organization_configurations USING btree (id);


--
-- Name: ix_organization_configurations_organization_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_organization_configurations_organization_id ON public.organization_configurations USING btree (organization_id);


--
-- Name: ix_organization_usage_cycles_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_organization_usage_cycles_id ON public.organization_usage_cycles USING btree (id);


--
-- Name: ix_organizations_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_organizations_provider_id ON public.organizations USING btree (provider_id);


--
-- Name: ix_tools_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tools_category ON public.tools USING btree (category);


--
-- Name: ix_tools_organization_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tools_organization_id ON public.tools USING btree (organization_id);


--
-- Name: ix_tools_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tools_status ON public.tools USING btree (status);


--
-- Name: ix_tools_tool_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_tools_tool_uuid ON public.tools USING btree (tool_uuid);


--
-- Name: ix_tools_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tools_uuid ON public.tools USING btree (tool_uuid);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_provider_id ON public.users USING btree (provider_id);


--
-- Name: ix_webhook_credentials_organization_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_webhook_credentials_organization_id ON public.external_credentials USING btree (organization_id);


--
-- Name: ix_webhook_credentials_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_webhook_credentials_uuid ON public.external_credentials USING btree (credential_uuid);


--
-- Name: ix_workflow_hash_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_workflow_hash_workflow_id ON public.workflow_definitions USING btree (workflow_hash, workflow_id);


--
-- Name: ix_workflow_templates_template_description; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_workflow_templates_template_description ON public.workflow_templates USING btree (template_description);


--
-- Name: ix_workflow_templates_template_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_workflow_templates_template_name ON public.workflow_templates USING btree (template_name);


--
-- Name: ix_workflows_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_workflows_name ON public.workflows USING btree (name);


--
-- Name: agent_triggers agent_triggers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: agent_triggers agent_triggers_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: campaigns campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: campaigns campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: campaigns campaigns_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- Name: embed_sessions embed_sessions_embed_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_sessions
    ADD CONSTRAINT embed_sessions_embed_token_id_fkey FOREIGN KEY (embed_token_id) REFERENCES public.embed_tokens(id) ON DELETE CASCADE;


--
-- Name: embed_sessions embed_sessions_workflow_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_sessions
    ADD CONSTRAINT embed_sessions_workflow_run_id_fkey FOREIGN KEY (workflow_run_id) REFERENCES public.workflow_runs(id) ON DELETE CASCADE;


--
-- Name: embed_tokens embed_tokens_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_tokens
    ADD CONSTRAINT embed_tokens_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: embed_tokens embed_tokens_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_tokens
    ADD CONSTRAINT embed_tokens_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: embed_tokens embed_tokens_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embed_tokens
    ADD CONSTRAINT embed_tokens_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: external_credentials external_credentials_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_credentials
    ADD CONSTRAINT external_credentials_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: external_credentials external_credentials_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_credentials
    ADD CONSTRAINT external_credentials_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: integrations integrations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: integrations integrations_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organizations(id);


--
-- Name: knowledge_base_chunks knowledge_base_chunks_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base_chunks
    ADD CONSTRAINT knowledge_base_chunks_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.knowledge_base_documents(id) ON DELETE CASCADE;


--
-- Name: knowledge_base_chunks knowledge_base_chunks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base_chunks
    ADD CONSTRAINT knowledge_base_chunks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: knowledge_base_documents knowledge_base_documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base_documents
    ADD CONSTRAINT knowledge_base_documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: knowledge_base_documents knowledge_base_documents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base_documents
    ADD CONSTRAINT knowledge_base_documents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: looptalk_conversations looptalk_conversations_test_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.looptalk_conversations
    ADD CONSTRAINT looptalk_conversations_test_session_id_fkey FOREIGN KEY (test_session_id) REFERENCES public.looptalk_test_sessions(id);


--
-- Name: looptalk_test_sessions looptalk_test_sessions_actor_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.looptalk_test_sessions
    ADD CONSTRAINT looptalk_test_sessions_actor_workflow_id_fkey FOREIGN KEY (actor_workflow_id) REFERENCES public.workflows(id);


--
-- Name: looptalk_test_sessions looptalk_test_sessions_adversary_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.looptalk_test_sessions
    ADD CONSTRAINT looptalk_test_sessions_adversary_workflow_id_fkey FOREIGN KEY (adversary_workflow_id) REFERENCES public.workflows(id);


--
-- Name: looptalk_test_sessions looptalk_test_sessions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.looptalk_test_sessions
    ADD CONSTRAINT looptalk_test_sessions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: organization_configurations organization_configurations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_configurations
    ADD CONSTRAINT organization_configurations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_usage_cycles organization_usage_cycles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_usage_cycles
    ADD CONSTRAINT organization_usage_cycles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: organization_users organization_users_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: organization_users organization_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: queued_runs queued_runs_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queued_runs
    ADD CONSTRAINT queued_runs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON DELETE CASCADE;


--
-- Name: queued_runs queued_runs_parent_queued_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queued_runs
    ADD CONSTRAINT queued_runs_parent_queued_run_id_fkey FOREIGN KEY (parent_queued_run_id) REFERENCES public.queued_runs(id);


--
-- Name: tools tools_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tools tools_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: user_configurations user_configurations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_configurations
    ADD CONSTRAINT user_configurations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_selected_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_selected_organization_id_fkey FOREIGN KEY (selected_organization_id) REFERENCES public.organizations(id);


--
-- Name: workflow_definitions workflow_definitions_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT workflow_definitions_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- Name: workflow_runs workflow_runs_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id);


--
-- Name: workflow_runs workflow_runs_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_definition_id_fkey FOREIGN KEY (definition_id) REFERENCES public.workflow_definitions(id);


--
-- Name: workflow_runs workflow_runs_queued_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_queued_run_id_fkey FOREIGN KEY (queued_run_id) REFERENCES public.queued_runs(id);


--
-- Name: workflow_runs workflow_runs_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- Name: workflows workflows_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: workflows workflows_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict gIBnoXxRqCNOSv5SdVIg5muhh0nnLavamdlrqKDaGVJGg3D1XuUKW2lXzm0G8A6

--
-- PostgreSQL database cluster dump complete
--

